<div id="heyoyaDiv"></div>

<script type="text/javascript">
	/*jQuery(document).ready(function(){
		var tabloaded=false;
		var tabloaddelay=3000;
		var tabloadcounter=0;
		jQuery(".wc-tabs li").click(function(){

			if(jQuery(this).find("a").text()=="Review"){
				setTimeout(function(){
					jQuery(".woocommerce-Tabs-panel--test_tab").attr("style","display:block !important;height:"+jQuery(".woocommerce-Tabs-panel--test_tab #heyB2BUI").height()+"px !important;");	
				},tabloaddelay);
				
			}else{
				if(tabloadcounter>0){
					setTimeout(function(){
						jQuery(".woocommerce-Tabs-panel--test_tab").attr("style","display:none !important;");
					},tabloaddelay);	
				}else{
					tabloadcounter++;
				}
				
			}
			
			if(!tabloaded){
				tabloaddelay=0;
				tabloaded=true;
			}
			// if(!tabloaded){
			// 	var url=jQuery("#heyB2BUI").attr("src"); jQuery("#heyB2BUI").attr("src",url); var style=jQuery("#heyB2BUI").attr("style"); var iframe='<iframe src="'+url+'" style="'+style+'"></iframe>'; jQuery("#heyB2BUI").replaceWith(iframe);

			// 	tabloaded=true;
			// }
		});
		
	});*/
</script>